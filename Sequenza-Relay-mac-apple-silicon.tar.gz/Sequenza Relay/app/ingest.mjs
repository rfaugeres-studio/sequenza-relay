/**
 * Acquisition RTSP permanente, INDÉPENDANTE de la lecture.
 *
 * FFmpeg reçoit le flux et le découpe sans réencoder la vidéo (`-c:v copy`) en segments MPEG-TS
 * d'environ `segmentSeconds`, coupés sur les images clés (la durée réelle suit le GOP de la caméra).
 * Chaque segment terminé est annoncé sur la sortie standard (liste CSV « nom,début,fin » en
 * secondes de flux) puis indexé en heure réelle :
 *   ancre = heure de réception du premier segment − sa fin (secondes de flux) ;
 *   un écart de plus de 2 s entre l'heure calculée et l'heure réelle ré-ancre l'horloge
 *   (horloge caméra qui dérive, horodatages non monotones) sans jamais réordonner l'index.
 *
 * Coupure, flux figé, erreur : FFmpeg est arrêté puis relancé (attente 1, 2, 4… 30 s).
 * Chaque relance est un nouveau « run » : la rupture est inscrite dans l'index, jamais comblée.
 */
import { spawn } from "node:child_process"
import { promises as fs } from "node:fs"
import path from "node:path"
import readline from "node:readline"
import { log, maskUrl } from "./util.mjs"

const BACKOFF = [1000, 2000, 4000, 8000, 15000, 30000]

/** Paramètres du flux lus dans le journal FFmpeg (« Stream #0:0: Video: h264 (High), yuv420p, 1920x1080, 25 fps »). */
export function parseStreamInfo(line) {
  const m = /Stream #\d+:\d+.*?: Video: (\w+)[^,]*,(?:[^,]*,)*? (\d{2,5})x(\d{2,5})[^,]*(?:,[^,]*)*?(?:, ([\d.]+) fps)?/.exec(line)
  if (!m) return null
  const fps = /([\d.]+) fps/.exec(line)
  return { codec: m[1], width: Number(m[2]), height: Number(m[3]), fps: fps ? Number(fps[1]) : null }
}

/** Ligne de liste de segments FFmpeg : « r3_000012.ts,24.080000,26.080000 ». */
export function parseSegmentLine(line) {
  const m = /^([^,]+\.ts),(-?[\d.]+),(-?[\d.]+)\s*$/.exec(line.trim())
  return m ? { file: m[1], start: Number(m[2]), end: Number(m[3]) } : null
}

/** Horloge : secondes de flux → heure réelle, ré-ancrée si l'écart dépasse 2 s. */
export class StreamClock {
  constructor(now = Date.now) {
    this.now = now
    this.anchor = null
    this.reanchors = 0
    this.lastEndMs = null
  }
  /** Segment terminé à l'instant présent : renvoie ses bornes en heure réelle. */
  map(start, end) {
    const t = this.now()
    if (this.anchor === null) this.anchor = t - end * 1000
    let startMs = this.anchor + start * 1000
    let endMs = this.anchor + end * 1000
    if (Math.abs(endMs - t) > 2000 || end < start || (this.lastEndMs !== null && startMs < this.lastEndMs - 500)) {
      // Horodatages incohérents : on se fie à l'heure de réception et à la durée annoncée.
      const dur = Math.max(0, Math.min((end - start) * 1000, 30_000))
      endMs = t
      startMs = Math.max(this.lastEndMs ?? t - dur, t - dur)
      this.anchor = t - end * 1000
      this.reanchors++
    }
    this.lastEndMs = endMs
    return { startMs: Math.round(startMs), endMs: Math.round(endMs) }
  }
}

export class Ingest {
  /**
   * @param {{ ring: import("./ring.mjs").ReplayRing, ffmpeg?: string, segmentSeconds?: number, onState?: (s: object) => void }} o
   */
  constructor(o) {
    this.ring = o.ring
    this.ffmpeg = o.ffmpeg ?? "ffmpeg"
    this.segmentSeconds = o.segmentSeconds ?? 2
    this.onState = o.onState ?? (() => {})
    this.proc = null
    this.run = 0
    this.attempt = 0
    this.stopped = true
    this.state = "idle"
    this.stream = null
    this.lastSegmentAt = 0
    this.metrics = { reconnects: 0, errors: 0, segments: 0, bitrateBps: null, lastError: null, connectedAt: null }
    this.watchdog = null
    this.retryTimer = null
  }

  setState(state, extra = {}) {
    this.state = state
    this.onState({ state, ...extra })
  }

  start(source) {
    this.source = source
    this.stopped = false
    this.attempt = 0
    this.spawnOnce()
    this.watchdog = setInterval(() => this.checkStall(), 2000)
  }

  /** Arrêt propre : aucun processus FFmpeg orphelin. */
  async stop() {
    this.stopped = true
    clearInterval(this.watchdog)
    clearTimeout(this.retryTimer)
    await this.kill()
    this.setState("idle")
  }

  async kill() {
    const p = this.proc
    if (!p) return
    this.proc = null
    await new Promise((resolve) => {
      const t = setTimeout(() => {
        try {
          p.kill("SIGKILL")
        } catch {
          /* déjà arrêté */
        }
        resolve()
      }, 3000)
      p.once("exit", () => {
        clearTimeout(t)
        resolve()
      })
      try {
        p.kill("SIGTERM")
      } catch {
        clearTimeout(t)
        resolve()
      }
    })
  }

  args(run) {
    const s = this.source
    const input = [
      "-hide_banner",
      "-nostdin",
      "-loglevel",
      "info",
      "-stats_period",
      "2",
      "-rtsp_transport",
      s.transport === "udp" ? "udp" : "tcp",
      "-timeout",
      "8000000",
      "-fflags",
      "+genpts+discardcorrupt",
      "-i",
      s.url,
    ]
    const out = [
      "-map",
      "0:v:0",
      "-map",
      "0:a:0?",
      "-c:v",
      "copy",
      // Audio éventuel des caméras (G.711, AAC…) : converti en AAC, léger, lisible partout.
      "-c:a",
      "aac",
      "-b:a",
      "96k",
      "-f",
      "segment",
      "-segment_time",
      String(this.segmentSeconds),
      "-segment_format",
      "mpegts",
      "-reset_timestamps",
      "0",
      "-segment_list",
      "pipe:1",
      "-segment_list_type",
      "csv",
      "-segment_list_flags",
      "+live",
      path.join(this.ring.dir, `r${run}_%06d.ts`),
    ]
    return [...input, ...out]
  }

  spawnOnce() {
    if (this.stopped) return
    const run = Date.now()
    this.run = run
    this.clock = new StreamClock()
    this.lastSegmentAt = Date.now()
    this.setState(this.attempt === 0 ? "connecting" : "reconnecting", { attempt: this.attempt })
    log("info", `Connexion à ${maskUrl(this.source.url)} (run ${run})`)
    const p = spawn(this.ffmpeg, this.args(run), { stdio: ["ignore", "pipe", "pipe"], windowsHide: true })
    this.proc = p
    const out = readline.createInterface({ input: p.stdout })
    out.on("line", (line) => void this.onSegment(line, run))
    const err = readline.createInterface({ input: p.stderr })
    err.on("line", (line) => this.onLog(line))
    p.on("error", (e) => {
      this.metrics.errors++
      this.metrics.lastError = e.code === "ENOENT" ? "FFmpeg introuvable : installez FFmpeg ou indiquez son chemin." : maskUrl(e.message)
      this.setState("error", { message: this.metrics.lastError })
    })
    p.on("exit", (code) => {
      if (this.proc === p) this.proc = null
      if (this.stopped) return
      this.metrics.errors++
      this.scheduleRetry(code)
    })
  }

  scheduleRetry(code) {
    if (this.stopped || this.retryTimer) return
    const delay = BACKOFF[Math.min(this.attempt, BACKOFF.length - 1)]
    this.attempt++
    this.metrics.reconnects++
    log("warn", `Flux interrompu (code ${code ?? "?"}), nouvelle tentative dans ${delay / 1000} s`)
    this.setState("reconnecting", { attempt: this.attempt, retryInMs: delay, message: this.metrics.lastError })
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null
      this.spawnOnce()
    }, delay)
  }

  /** Flux figé (plus aucun segment) : FFmpeg est relancé, l'acquisition ne reste jamais muette. */
  checkStall() {
    if (this.stopped || !this.proc) return
    const limit = Math.max(15_000, this.segmentSeconds * 4000 + 8000)
    if (Date.now() - this.lastSegmentAt > limit) {
      this.metrics.lastError = "Flux figé : aucune image reçue depuis plusieurs secondes."
      log("warn", this.metrics.lastError)
      const p = this.proc
      void this.kill().then(() => {
        if (!this.proc && p) this.scheduleRetry("stall")
      })
    }
  }

  onLog(line) {
    const info = parseStreamInfo(line)
    if (info && /Input #0|Stream #0:\d+.*Video/.test(line) && !/Output|->/.test(line)) {
      const changed = this.stream && (this.stream.codec !== info.codec || this.stream.width !== info.width || this.stream.height !== info.height)
      this.stream = info
      if (changed) log("warn", `Paramètres du flux changés : ${info.codec} ${info.width}x${info.height}`)
    }
    const br = /bitrate=\s*([\d.]+)kbits\/s/.exec(line)
    if (br) this.metrics.bitrateBps = Number(br[1]) * 1000
    if (/error|failed|Invalid|refused|401|404|timed out/i.test(line) && !/^\s*frame=/.test(line)) this.metrics.lastError = maskUrl(line.trim()).slice(0, 300)
  }

  async onSegment(line, run) {
    const seg = parseSegmentLine(line)
    if (!seg || run !== this.run) return
    const file = path.join(this.ring.dir, seg.file)
    const st = await fs.stat(file).catch(() => null)
    // Écriture incomplète ou fichier vide : jamais indexé (et supprimé).
    if (!st || st.size < 188) {
      await fs.rm(file, { force: true })
      return
    }
    const { startMs, endMs } = this.clock.map(seg.start, seg.end)
    if (this.state !== "live") {
      this.attempt = 0
      this.metrics.connectedAt = Date.now()
      this.metrics.lastError = null
      this.setState("live", { stream: this.stream })
    }
    this.lastSegmentAt = Date.now()
    this.metrics.segments++
    try {
      await this.ring.add({ seq: this.ring.nextSeq(), file: seg.file, run, startMs, endMs, mediaMs: Math.round((seg.end - seg.start) * 1000), bytes: st.size, codec: this.stream?.codec ?? null })
    } catch (e) {
      // Disque plein ou illisible : signalé, jamais silencieux.
      this.metrics.errors++
      this.metrics.lastError = `Écriture impossible : ${e.code === "ENOSPC" ? "disque plein" : e.message}`
      this.setState("error", { message: this.metrics.lastError })
    }
  }
}

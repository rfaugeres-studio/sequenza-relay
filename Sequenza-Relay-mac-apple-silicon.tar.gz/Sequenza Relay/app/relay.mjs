/**
 * Sequenza Relay : acquisition RTSP + buffer circulaire + lecture HLS + export, en local.
 *
 * Avec MediaMTX (npm run relay:setup) : direct WebRTC à faible latence et conversion H.265 → H.264,
 * voir mediamtx.mjs. Sans MediaMTX : FFmpeg lit la caméra directement, direct en HLS.
 *
 * Sécurité :
 *  - écoute sur 127.0.0.1 uniquement (jamais sur le réseau) ;
 *  - seules les pages de Sequenza (origines autorisées) peuvent l'appeler ; toute autre origine
 *    reçoit 403, et les requêtes sans origine sont refusées sauf `/health` ;
 *  - l'adresse RTSP (avec identifiants) reste dans la configuration du relais, sur cet ordinateur ;
 *    elle n'est jamais renvoyée en clair ni écrite dans les journaux.
 */
import { randomUUID } from "node:crypto"
import { createReadStream, promises as fs } from "node:fs"
import http from "node:http"
import os from "node:os"
import path from "node:path"
import { ExportJob } from "./export.mjs"
import { Ingest } from "./ingest.mjs"
import { findMediamtx, Gateway } from "./mediamtx.mjs"
import { ReplayRing } from "./ring.mjs"
import { log, maskUrl, writeAtomic } from "./util.mjs"

export const DEFAULT_PORT = 7765
export const DEFAULT_ORIGINS = ["https://www.sequenza-video.com", "https://sequenza-video.com", "https://sequenza-two.vercel.app", "http://localhost:3210", "http://localhost:3220", "http://localhost:3222", "http://127.0.0.1:3210"]
export const DURATIONS_MIN = [5, 15, 30, 60, 120]

export function defaultStorageDir() {
  const base = process.env.LOCALAPPDATA ?? path.join(os.homedir(), ".local", "share")
  return path.join(base, "Sequenza", "relay")
}

/** Validation de la source : adresse rtsp(s)://, durée 1 à 240 min, quota ≥ 0,5 Go. */
export function validateSource(input, previous = null) {
  const errors = []
  let url = typeof input.url === "string" ? input.url.trim() : ""
  // Adresse masquée renvoyée par l'interface : on garde l'adresse enregistrée.
  if (url.includes("***@") && previous?.url) url = previous.url
  try {
    const u = new URL(url)
    if (!/^rtsps?:$/.test(u.protocol)) errors.push("L'adresse doit commencer par rtsp://")
    if (!u.hostname) errors.push("Adresse de la caméra manquante.")
  } catch {
    errors.push("Adresse RTSP invalide.")
  }
  const durationMin = Number(input.durationMin ?? 60)
  if (!Number.isFinite(durationMin) || durationMin < 1 || durationMin > 240) errors.push("Durée du buffer : entre 1 et 240 minutes.")
  const quotaGb = Number(input.quotaGb ?? 20)
  if (!Number.isFinite(quotaGb) || quotaGb < 0.5) errors.push("Quota disque : 0,5 Go au minimum.")
  const transport = input.transport === "udp" ? "udp" : "tcp"
  const transcode = ["always", "off"].includes(input.transcode) ? input.transcode : "auto"
  return errors.length
    ? { ok: false, errors }
    : { ok: true, source: { url, name: String(input.name ?? "Caméra").slice(0, 60) || "Caméra", transport, durationMin, quotaGb, transcode, autoReconnect: input.autoReconnect !== false, autoStart: input.autoStart !== false } }
}

export class Relay {
  constructor({ storageDir = defaultStorageDir(), ffmpeg = "ffmpeg", origins = DEFAULT_ORIGINS, segmentSeconds = 2, now, mediamtx, buffer } = {}) {
    Object.assign(this, { storageDir, ffmpeg, origins: new Set(origins), segmentSeconds })
    this.bufferDir = path.join(storageDir, "buffer")
    this.exportDir = path.join(storageDir, "exports")
    this.configFile = path.join(storageDir, "config.json")
    this.source = null
    this.events = []
    this.exports = new Map()
    this.seekTimes = []
    this.now = now ?? Date.now
    this.ring = new ReplayRing({ dir: this.bufferDir, durationMs: 3_600_000, quotaBytes: 20 * 1024 ** 3, now: this.now, onEvent: (e) => this.event(e) })
    this.ingest = new Ingest({ ring: this.ring, ffmpeg, segmentSeconds, onState: (s) => this.event({ type: "state", ...s }) })
    // Passerelle MediaMTX si installée (désactivable avec `mediamtx: false`).
    const bin = mediamtx === false ? null : findMediamtx(typeof mediamtx === "string" ? mediamtx : undefined)
    this.gateway = bin ? new Gateway({ bin, workDir: path.join(storageDir, "mediamtx"), ffmpeg }) : null
    // Tampon disque (FFmpeg + segments) : seulement sans MediaMTX, ou sur demande (`buffer: true`).
    // Avec MediaMTX, le séquençage en direct n'a besoin ni de FFmpeg ni du tampon.
    this.useBuffer = !this.gateway || buffer === true
    this.whep = new Map()
  }

  event(e) {
    this.events.push({ at: Date.now(), ...e })
    if (this.events.length > 200) this.events.shift()
    if (e.type !== "rotated" && e.type !== "state") log("info", `Évènement ${e.type}`, e)
  }

  async init() {
    await fs.mkdir(this.storageDir, { recursive: true })
    await fs.mkdir(this.exportDir, { recursive: true })
    // Exports laissés par une session précédente : supprimés (fichiers temporaires jamais conservés).
    for (const f of await fs.readdir(this.exportDir)) await fs.rm(path.join(this.exportDir, f), { force: true })
    try {
      const cfg = JSON.parse(await fs.readFile(this.configFile, "utf8"))
      const v = validateSource(cfg.source ?? {})
      if (v.ok) this.applySource(v.source)
    } catch {
      /* pas encore configuré */
    }
    await this.ring.load()
    this.diskTimer = setInterval(() => void this.checkDisk(), 10_000)
    if (this.source?.autoStart) this.start()
  }

  applySource(source) {
    this.source = source
    this.ring.durationMs = source.durationMin * 60_000
    this.ring.quotaBytes = source.quotaGb * 1024 ** 3
  }

  async saveConfig() {
    await writeAtomic(this.configFile, JSON.stringify({ version: 1, source: this.source }, null, 2))
  }

  start() {
    if (!this.source) return false
    if (!this.gateway) {
      if (this.ingest.stopped) this.ingest.start(this.source)
      return true
    }
    if (this.pipeline) return true
    if (!this.useBuffer) {
      this.pipeline = { path: null }
      void this.gateway.start(this.source, { transcode: this.source.transcode ?? "auto" })
      return true
    }
    // MediaMTX tient la seule connexion à la caméra ; l'acquisition du replay lit sa copie locale,
    // dès qu'elle est prête et dans un codec que le navigateur sait lire.
    const pipeline = { path: null }
    this.pipeline = pipeline
    void this.gateway.start(this.source, { transcode: this.source.transcode ?? "auto" }).then(() => {
      if (this.pipeline !== pipeline) return
      this.pipelineTimer = setInterval(() => {
        const g = this.gateway.info
        if (!g.ready || !g.livePath || this.pipeline !== pipeline) return
        if (pipeline.path !== g.livePath) {
          pipeline.path = g.livePath
          void this.ingest.stop().then(() => this.pipeline === pipeline && this.ingest.start({ ...this.source, url: this.gateway.readUrl(g.livePath), transport: "tcp" }))
        }
      }, 500)
    })
    return true
  }

  async stop() {
    clearInterval(this.pipelineTimer)
    this.pipeline = null
    await this.ingest.stop()
    if (this.gateway) await this.gateway.stop()
    this.whep.clear()
  }

  /** Espace disque : en dessous de 1 Go libre, le buffer se réduit ; en dessous de 200 Mo, l'acquisition s'arrête (signalé). */
  async checkDisk() {
    if (!this.useBuffer) return
    try {
      const st = await fs.statfs(this.storageDir)
      const free = st.bavail * st.bsize
      this.freeBytes = free
      if (free < 200 * 1024 ** 2 && !this.ingest.stopped) {
        this.event({ type: "disk-full", message: "Disque presque plein : acquisition arrêtée pour protéger l'ordinateur." })
        await this.ingest.stop()
        this.ingest.metrics.lastError = "Disque presque plein : acquisition arrêtée."
        this.ingest.setState("error", { message: this.ingest.metrics.lastError })
      } else if (free < 1024 ** 3 && this.ring.bytes > 0) {
        this.ring.quotaBytes = Math.max(256 * 1024 ** 2, this.ring.bytes - (1024 ** 3 - free))
        await this.ring.prune()
        this.event({ type: "disk-low", message: "Espace disque faible : la durée conservée est réduite." })
      }
    } catch {
      /* statfs indisponible : le quota reste la seule limite */
    }
  }

  status() {
    const w = this.ring.window()
    const m = this.ingest.metrics
    const gw = this.gateway?.status() ?? { enabled: false }
    const lastError = m.lastError ?? (this.gateway && !gw.ready ? gw.lastError : null)
    // Caméra attendue par MediaMTX : l'acquisition n'a pas encore commencé, mais on est en connexion.
    const state = !this.useBuffer
      ? this.pipeline
        ? gw.ready
          ? "live"
          : gw.restarts
            ? "reconnecting"
            : "connecting"
        : "idle"
      : this.pipeline && this.ingest.stopped
        ? m.reconnects || gw.restarts
          ? "reconnecting"
          : "connecting"
        : this.ingest.stopped
          ? this.ingest.state === "error"
            ? "error"
            : "idle"
          : this.ingest.state
    const avg = this.seekTimes.length ? Math.round(this.seekTimes.reduce((a, b) => a + b, 0) / this.seekTimes.length) : null
    return {
      version: 1,
      configured: !!this.source,
      source: this.source ? { ...this.source, url: maskUrl(this.source.url) } : null,
      state,
      stream: this.useBuffer ? this.ingest.stream : (this.gateway.info.video ?? null),
      buffer: this.useBuffer,
      gateway: gw,
      window: { ...w, nowMs: this.now(), durationMs: this.ring.durationMs, availableMs: this.ring.availableMs() },
      metrics: { ...m, lastError: lastError ? maskUrl(lastError) : null, deferred: this.ring.deferred, freeBytes: this.freeBytes ?? null, quotaBytes: this.ring.quotaBytes, avgSeekMs: avg, memoryRss: process.memoryUsage().rss, reanchors: this.ingest.clock?.reanchors ?? 0 },
      events: this.events.slice(-20).map((e) => ({ ...e, message: e.message ? maskUrl(e.message) : undefined })),
    }
  }

  /** Liste de lecture HLS de toute la fenêtre (direct + historique), ruptures et heure réelle incluses. */
  playlist() {
    const segs = this.ring.segments
    const target = Math.max(2, Math.ceil(Math.max(0, ...segs.map((s) => s.mediaMs)) / 1000))
    const lines = ["#EXTM3U", "#EXT-X-VERSION:6", `#EXT-X-TARGETDURATION:${target}`, `#EXT-X-MEDIA-SEQUENCE:${segs[0]?.seq ?? 0}`, `#EXT-X-DISCONTINUITY-SEQUENCE:${segs[0]?.discSeq ?? 0}`]
    segs.forEach((s, i) => {
      if (i > 0 && s.discontinuity) lines.push("#EXT-X-DISCONTINUITY")
      lines.push(`#EXT-X-PROGRAM-DATE-TIME:${new Date(s.startMs).toISOString()}`)
      lines.push(`#EXTINF:${(s.mediaMs / 1000).toFixed(3)},`)
      lines.push(`seg/${s.file}`)
    })
    return `${lines.join("\n")}\n`
  }

  // ---------- HTTP ----------

  listen(port = DEFAULT_PORT, host = "127.0.0.1") {
    this.server = http.createServer((req, res) => void this.handle(req, res).catch((e) => this.reply(res, 500, { ok: false, error: maskUrl(e.message) })))
    return new Promise((resolve) => this.server.listen(port, host, () => resolve(this.server.address().port)))
  }

  async close() {
    clearInterval(this.diskTimer)
    for (const j of this.exports.values()) await j.cancel()
    await this.stop()
    // Les onglets Sequenza ouverts gardent des connexions HTTP actives : on les ferme, sinon l'arrêt attendrait.
    await new Promise((r) => {
      if (!this.server) return r()
      this.server.close(() => r())
      this.server.closeAllConnections()
    })
  }

  cors(req, res) {
    const origin = req.headers.origin
    if (origin && this.origins.has(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin)
      res.setHeader("Vary", "Origin")
      res.setHeader("Access-Control-Allow-Headers", "content-type, if-match")
      res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
      res.setHeader("Access-Control-Expose-Headers", "Location, ETag")
      // Accès réseau privé (Chrome) : page publique HTTPS → relais local.
      res.setHeader("Access-Control-Allow-Private-Network", "true")
    }
    return origin
  }

  reply(res, status, body, headers = {}) {
    res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers })
    res.end(JSON.stringify(body))
  }

  async rawBody(req, max = 64_000) {
    let raw = ""
    for await (const chunk of req) {
      raw += chunk
      if (raw.length > max) throw new Error("requête trop volumineuse")
    }
    return raw
  }

  /**
   * WebRTC (WHEP) relayé vers MediaMTX : le navigateur ne voit que le relais (origines vérifiées),
   * MediaMTX n'accepte que l'utilisateur interne du relais.
   */
  async whepProxy(req, res, p) {
    const g = this.gateway
    if (!g?.info.ready) return this.reply(res, 503, { ok: false, error: "Direct WebRTC indisponible pour l'instant." })
    if (p === "/webrtc/whep" && req.method === "POST") {
      const offer = await this.rawBody(req)
      const r = await fetch(g.whepUrl(), { method: "POST", headers: { "content-type": "application/sdp", authorization: g.authHeader() }, body: offer })
      const answer = await r.text()
      if (r.status !== 201) return this.reply(res, 502, { ok: false, error: `WebRTC refusé par la passerelle (${r.status}).` })
      const id = randomUUID()
      this.whep.set(id, new URL(r.headers.get("location") ?? "", g.whepUrl()).href)
      if (this.whep.size > 50) this.whep.delete(this.whep.keys().next().value)
      const etag = r.headers.get("etag")
      res.writeHead(201, { "Content-Type": "application/sdp", Location: `/webrtc/session/${id}`, ...(etag ? { ETag: etag } : {}), "Cache-Control": "no-store" })
      return res.end(answer)
    }
    const m = /^\/webrtc\/session\/([\w-]+)$/.exec(p)
    const target = m && this.whep.get(m[1])
    if (!target) return this.reply(res, 404, { ok: false, error: "Session WebRTC inconnue" })
    if (req.method === "PATCH") {
      const r = await fetch(target, { method: "PATCH", headers: { "content-type": "application/trickle-ice-sdpfrag", "if-match": req.headers["if-match"] ?? "*", authorization: g.authHeader() }, body: await this.rawBody(req) })
      return res.writeHead(r.status).end()
    }
    if (req.method === "DELETE") {
      this.whep.delete(m[1])
      await fetch(target, { method: "DELETE", headers: { authorization: g.authHeader() } }).catch(() => undefined)
      return res.writeHead(200).end()
    }
    return this.reply(res, 405, { ok: false })
  }

  /**
   * Direct HLS de secours servi par MediaMTX, relayé (mêmes contrôles d'origine). Les listes de lecture
   * sont réécrites pour que chaque adresse repasse par le relais.
   */
  async hlsProxy(res, p, search = "") {
    const g = this.gateway
    if (!g?.info.ready || !g.info.livePath) return this.reply(res, 503, { ok: false, error: "Direct pas encore disponible." })
    const rest = p === "/live.m3u8" ? `${g.info.livePath}/index.m3u8` : p.slice("/hls/".length)
    if (rest.includes("..")) return this.reply(res, 400, { ok: false })
    // La session HLS de MediaMTX est portée par l'adresse (?session=…) : transmise telle quelle.
    const r = await fetch(g.hlsUrl(rest) + (p === "/live.m3u8" ? "" : search), { headers: { authorization: g.authHeader() } })
    if (!r.ok) return this.reply(res, r.status === 404 ? 404 : 502, { ok: false })
    const type = r.headers.get("content-type") ?? ""
    if (/mpegurl/i.test(type) || rest.endsWith(".m3u8")) {
      const base = rest.slice(0, rest.lastIndexOf("/") + 1)
      const text = (await r.text()).replace(/^(?!#)(\S+)$/gm, (u) => (/^https?:/.test(u) ? u : `/hls/${base}${u}`)).replace(/URI="(?!https?:)([^"]+)"/g, (_m, u) => `URI="/hls/${base}${u}"`)
      res.writeHead(200, { "Content-Type": "application/vnd.apple.mpegurl", "Cache-Control": "no-store" })
      return res.end(text)
    }
    res.writeHead(200, { "Content-Type": type || "application/octet-stream", "Cache-Control": "no-store" })
    return res.end(Buffer.from(await r.arrayBuffer()))
  }

  async body(req) {
    let raw = ""
    for await (const chunk of req) {
      raw += chunk
      if (raw.length > 64_000) throw new Error("requête trop volumineuse")
    }
    return raw ? JSON.parse(raw) : {}
  }

  async handle(req, res) {
    const origin = this.cors(req, res)
    const url = new URL(req.url, "http://relay")
    const p = url.pathname
    if (req.method === "OPTIONS") return res.writeHead(origin && this.origins.has(origin) ? 204 : 403).end()
    if (p === "/health") return this.reply(res, 200, { ok: true, app: "sequenza-relay", version: 1 })
    if (!origin || !this.origins.has(origin)) return this.reply(res, 403, { ok: false, error: "Origine non autorisée" })

    if (p === "/status" && req.method === "GET") return this.reply(res, 200, this.status())
    if (p.startsWith("/webrtc/")) return this.whepProxy(req, res, p)
    if (p === "/source" && req.method === "POST") {
      const v = validateSource(await this.body(req), this.source)
      if (!v.ok) return this.reply(res, 400, { ok: false, errors: v.errors })
      const changed = !this.source || this.source.url !== v.source.url || this.source.transport !== v.source.transport || this.source.transcode !== v.source.transcode
      this.applySource(v.source)
      await this.saveConfig()
      await this.ring.prune()
      if (changed && (this.pipeline || !this.ingest.stopped)) {
        await this.stop()
        this.start()
      }
      return this.reply(res, 200, { ok: true, status: this.status() })
    }
    if (p === "/start" && req.method === "POST") return this.reply(res, this.start() ? 200 : 400, { ok: !!this.source })
    if (p === "/stop" && req.method === "POST") {
      await this.stop()
      return this.reply(res, 200, { ok: true })
    }
    if (!this.useBuffer && (p === "/live.m3u8" || p.startsWith("/hls/"))) return this.hlsProxy(res, p, url.search)
    if (p === "/live.m3u8") {
      res.writeHead(200, { "Content-Type": "application/vnd.apple.mpegurl", "Cache-Control": "no-store" })
      return res.end(this.playlist())
    }
    if (p.startsWith("/seg/")) {
      const name = path.basename(p.slice(5))
      const seg = this.ring.segments.find((s) => s.file === name)
      if (!seg) return this.reply(res, 404, { ok: false, error: "Segment expiré" })
      // Lecture en cours : le segment est protégé le temps de l'envoi.
      const owner = `read:${randomUUID()}`
      this.ring.lock(owner, seg.startMs, seg.endMs, 60_000)
      res.writeHead(200, { "Content-Type": "video/mp2t", "Content-Length": seg.bytes, "Cache-Control": "private, max-age=3600" })
      const stream = createReadStream(path.join(this.bufferDir, name))
      stream.on("close", () => this.ring.unlock(owner))
      stream.on("error", () => res.destroy())
      return stream.pipe(res)
    }
    if (p === "/playhead" && req.method === "POST") {
      const b = await this.body(req)
      const at = Number(b.atMs)
      if (Number.isFinite(at)) this.ring.lock(`play:${String(b.client ?? "x").slice(0, 40)}`, at - 10_000, at + 60_000, 20_000)
      if (Number.isFinite(Number(b.seekMs))) {
        this.seekTimes.push(Number(b.seekMs))
        if (this.seekTimes.length > 50) this.seekTimes.shift()
      }
      return this.reply(res, 200, { ok: true })
    }
    if (p === "/export" && req.method === "POST") {
      const b = await this.body(req)
      const inMs = Number(b.inMs)
      const outMs = Number(b.outMs)
      if (!Number.isFinite(inMs) || !Number.isFinite(outMs) || outMs <= inMs) return this.reply(res, 400, { ok: false, error: "Points IN / OUT invalides." })
      const job = new ExportJob({ id: randomUUID().slice(0, 8), ring: this.ring, ffmpeg: this.ffmpeg, inMs, outMs, precise: !!b.precise, outDir: this.exportDir })
      this.exports.set(job.id, job)
      void job.run()
      return this.reply(res, 200, { ok: true, job: job.toJSON() })
    }
    const ex = /^\/export\/([\w-]+)(\/file)?$/.exec(p)
    if (ex) {
      const job = this.exports.get(ex[1])
      if (!job) return this.reply(res, 404, { ok: false, error: "Export inconnu" })
      if (req.method === "DELETE") {
        await job.cancel()
        await fs.rm(job.file, { force: true })
        this.exports.delete(job.id)
        return this.reply(res, 200, { ok: true })
      }
      if (ex[2]) {
        if (job.state !== "done") return this.reply(res, 409, { ok: false, error: "Export pas terminé" })
        res.writeHead(200, { "Content-Type": "video/mp4", "Content-Length": job.bytes, "Content-Disposition": `attachment; filename="sequenza-${job.id}.mp4"` })
        return createReadStream(job.file).pipe(res)
      }
      return this.reply(res, 200, { ok: true, job: job.toJSON() })
    }
    return this.reply(res, 404, { ok: false, error: "Introuvable" })
  }
}

#!/usr/bin/env node
/**
 * Sequenza Relay — à lancer sur l'ordinateur relié à la caméra :
 *
 *   npm run relay
 *   npm run relay -- --port 7765 --storage "D:\Sequenza" --ffmpeg "C:\ffmpeg\bin\ffmpeg.exe"
 *
 * MediaMTX (direct WebRTC) : `npm run relay:setup` l'installe ; `--auto-setup` l'installe tout seul s'il
 * manque (version téléchargeable du relais). `--mediamtx <chemin>` pour un autre emplacement,
 * `--no-mediamtx` pour s'en passer (FFmpeg obligatoire alors, direct HLS). `--buffer` garde aussi la
 * dernière heure sur le disque (inutile pour le séquençage en direct).
 *
 * Ensuite, dans Sequenza Live : onglet Caméra IP. Ctrl+C (ou fermer la fenêtre) arrête proprement.
 */
import { findMediamtx } from "./mediamtx.mjs"
import { DEFAULT_PORT, defaultStorageDir, Relay } from "./relay.mjs"
import { log } from "./util.mjs"

const arg = (name, fallback) => {
  const i = process.argv.indexOf(`--${name}`)
  return i > 0 ? process.argv[i + 1] : fallback
}
const flag = (name) => process.argv.includes(`--${name}`)

console.log("Sequenza Relay — caméra IP pour le séquençage en direct")
console.log("Laissez cette fenêtre ouverte pendant le match. Pour arrêter : fermez-la ou appuyez sur Ctrl+C.\n")

if (flag("auto-setup") && !flag("no-mediamtx") && !arg("mediamtx") && !findMediamtx()) {
  try {
    const { installMediamtx } = await import("./setup-mediamtx.mjs")
    await installMediamtx(undefined, (m) => log("info", m))
  } catch (e) {
    log("error", `MediaMTX n'a pas pu être installé (${e instanceof Error ? e.message : e}). Vérifiez la connexion Internet, puis relancez Sequenza Relay.`)
  }
}

const relay = new Relay({
  storageDir: arg("storage", process.env.SEQUENZA_RELAY_DIR ?? defaultStorageDir()),
  ffmpeg: arg("ffmpeg", process.env.FFMPEG_PATH ?? "ffmpeg"),
  origins: arg("origins") ? arg("origins").split(",") : undefined,
  mediamtx: flag("no-mediamtx") ? false : arg("mediamtx"),
  buffer: flag("buffer"),
})
await relay.init()
let port
try {
  port = await relay.listen(Number(arg("port", process.env.SEQUENZA_RELAY_PORT ?? DEFAULT_PORT)))
} catch (e) {
  if (e && e.code === "EADDRINUSE") log("error", "Sequenza Relay tourne déjà sur cet ordinateur (ou le port 7765 est occupé). Fermez l'autre fenêtre, puis relancez.")
  else log("error", e instanceof Error ? e.message : String(e))
  process.exit(1)
}
log("info", `Sequenza Relay prêt sur http://127.0.0.1:${port}`)
log("info", relay.gateway ? "Passerelle MediaMTX active : direct à faible latence (WebRTC)." : "MediaMTX absent : direct en HLS (quelques secondes de retard). Pour le WebRTC : npm run relay:setup")
log("info", "Ouvrez Sequenza › Sequenza Live › onglet « Caméra IP ».")

let closing = false
const shutdown = async () => {
  if (closing) return
  closing = true
  log("info", "Arrêt du relais…")
  await relay.close()
  process.exit(0)
}
process.on("SIGINT", shutdown)
process.on("SIGTERM", shutdown)
process.on("SIGHUP", shutdown)

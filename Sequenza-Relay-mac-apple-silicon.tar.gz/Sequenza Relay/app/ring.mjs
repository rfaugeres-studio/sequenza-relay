/**
 * Buffer circulaire sur disque : segments MPEG-TS compressés (jamais d'images décodées en mémoire).
 *
 * Chaque segment est indexé en HEURE RÉELLE (ms depuis l'époque) : début, fin, durée média,
 * « run » (une connexion = un run ; changer de run = rupture), codec, taille, chemin.
 * La position dans le flux ne dépend jamais du nom ni de la date des fichiers.
 *
 * Rotation : les segments dont la fin est plus ancienne que (direct − durée) sont supprimés,
 * SAUF s'ils sont verrouillés (lecture en cours, export) : leur suppression est différée.
 * Quota disque : au-delà, les plus anciens non verrouillés partent en premier, et l'incident est signalé.
 */
import { promises as fs } from "node:fs"
import path from "node:path"
import { writeAtomic } from "./util.mjs"

export class ReplayRing {
  /**
   * @param {{ dir: string, durationMs: number, quotaBytes: number, now?: () => number, onEvent?: (e: object) => void }} o
   */
  constructor(o) {
    this.dir = o.dir
    this.durationMs = o.durationMs
    this.quotaBytes = o.quotaBytes
    this.now = o.now ?? Date.now
    this.onEvent = o.onEvent ?? (() => {})
    /** @type {{ seq: number, file: string, run: number, startMs: number, endMs: number, mediaMs: number, bytes: number, codec: string | null, discontinuity: boolean, discSeq: number }[]} */
    this.segments = []
    /** Verrous : propriétaire → { fromMs, toMs, untilMs } (heure réelle). */
    this.locks = new Map()
    this.bytes = 0
    this.deferred = 0
    this.seq = 0
    /** Fichiers à supprimer dont la suppression a échoué (ouverts par un lecteur sous Windows) : réessayés. */
    this.trash = []
  }

  async removeFile(file) {
    try {
      await fs.rm(path.join(this.dir, file), { force: true })
    } catch {
      this.trash.push(file)
    }
  }

  get indexFile() {
    return path.join(this.dir, "index.json")
  }

  /** Reprise après redémarrage : index relu, fichiers absents oubliés, fichiers hors index (orphelins) supprimés. */
  async load() {
    await fs.mkdir(this.dir, { recursive: true })
    let saved = []
    try {
      saved = JSON.parse(await fs.readFile(this.indexFile, "utf8")).segments ?? []
    } catch {
      saved = []
    }
    const kept = []
    for (const s of saved) {
      const st = await fs.stat(path.join(this.dir, s.file)).catch(() => null)
      if (st && st.size === s.bytes) kept.push(s)
    }
    this.segments = kept.sort((a, b) => a.startMs - b.startMs)
    this.bytes = kept.reduce((t, s) => t + s.bytes, 0)
    this.seq = kept.reduce((m, s) => Math.max(m, s.seq), 0)
    const known = new Set(kept.map((s) => s.file))
    let orphans = 0
    for (const name of await fs.readdir(this.dir)) {
      if (/\.ts$/.test(name) && !known.has(name)) {
        await fs.rm(path.join(this.dir, name), { force: true })
        orphans++
      }
      if (/\.tmp$/.test(name)) await fs.rm(path.join(this.dir, name), { force: true })
    }
    if (orphans) this.onEvent({ type: "orphans-removed", count: orphans })
    await this.prune()
  }

  async save() {
    await writeAtomic(this.indexFile, JSON.stringify({ version: 1, segments: this.segments }))
  }

  nextSeq() {
    return ++this.seq
  }

  /** Segment terminé et complet sur le disque : ajouté à l'index, puis rotation. */
  async add(seg) {
    const prev = this.segments.at(-1)
    const discontinuity = !prev || prev.run !== seg.run || seg.startMs - prev.endMs > 1500
    // Compteur de ruptures (lecteur HLS : EXT-X-DISCONTINUITY-SEQUENCE).
    const discSeq = prev ? prev.discSeq + (discontinuity ? 1 : 0) : 0
    this.segments.push({ ...seg, discontinuity, discSeq })
    this.bytes += seg.bytes
    await this.prune()
    await this.save()
    return this.segments.at(-1)
  }

  /** Plage disponible et trous (heure réelle). */
  window() {
    const first = this.segments[0]
    const last = this.segments.at(-1)
    const gaps = []
    for (let i = 1; i < this.segments.length; i++) {
      const a = this.segments[i - 1]
      const b = this.segments[i]
      if (b.discontinuity && b.startMs - a.endMs > 1000) gaps.push({ fromMs: a.endMs, toMs: b.startMs })
    }
    return { startMs: first?.startMs ?? null, endMs: last?.endMs ?? null, gaps, segments: this.segments.length, bytes: this.bytes }
  }

  /** Segment qui contient l'instant (ou le premier après, dans un trou). */
  find(atMs) {
    let lo = 0
    let hi = this.segments.length - 1
    while (lo <= hi) {
      const mid = (lo + hi) >> 1
      const s = this.segments[mid]
      if (atMs < s.startMs) hi = mid - 1
      else if (atMs >= s.endMs) lo = mid + 1
      else return s
    }
    return this.segments[lo] ?? null
  }

  range(fromMs, toMs) {
    return this.segments.filter((s) => s.endMs > fromMs && s.startMs < toMs)
  }

  /** Protège une plage (lecture, export) jusqu'à `untilMs` ; renouvelable. */
  lock(owner, fromMs, toMs, ttlMs) {
    this.locks.set(owner, { fromMs, toMs, untilMs: ttlMs === Infinity ? Infinity : this.now() + ttlMs })
  }

  unlock(owner) {
    this.locks.delete(owner)
  }

  isLocked(seg) {
    const t = this.now()
    for (const [owner, l] of this.locks) {
      if (l.untilMs < t) {
        this.locks.delete(owner)
        continue
      }
      if (seg.endMs > l.fromMs && seg.startMs < l.toMs) return true
    }
    return false
  }

  /** Rotation : fenêtre de durée, puis quota. Un segment verrouillé n'est jamais supprimé. */
  async prune() {
    const last = this.segments.at(-1)
    if (!last) return
    const limit = last.endMs - this.durationMs
    const keep = []
    const remove = []
    let deferred = 0
    for (const s of this.segments) {
      if (s.endMs <= limit) {
        if (this.isLocked(s)) {
          deferred++
          keep.push(s)
        } else remove.push(s)
      } else keep.push(s)
    }
    // Quota : les plus anciens d'abord, toujours hors verrous et jamais le dernier segment.
    let bytes = keep.reduce((t, s) => t + s.bytes, 0)
    let overQuota = false
    for (let i = 0; bytes > this.quotaBytes && i < keep.length - 1; ) {
      const s = keep[i]
      if (this.isLocked(s)) {
        i++
        continue
      }
      overQuota = true
      keep.splice(i, 1)
      remove.push(s)
      bytes -= s.bytes
    }
    const retry = this.trash.splice(0)
    for (const f of retry) await this.removeFile(f)
    for (const s of remove) await this.removeFile(s.file)
    this.segments = keep
    this.bytes = bytes
    if (deferred !== this.deferred) this.onEvent({ type: "deferred", count: deferred })
    this.deferred = deferred
    if (overQuota) this.onEvent({ type: "quota", message: "Quota disque atteint : la durée conservée est réduite." })
    if (remove.length) this.onEvent({ type: "rotated", count: remove.length })
  }

  /** Durée réellement disponible (ms), trous exclus. */
  availableMs() {
    return this.segments.reduce((t, s) => t + (s.endMs - s.startMs), 0)
  }

  /** Vide entièrement le buffer (fermeture de la source à la demande de l'utilisateur). */
  async clear() {
    for (const s of this.segments) await this.removeFile(s.file)
    this.segments = []
    this.bytes = 0
    await this.save()
  }
}

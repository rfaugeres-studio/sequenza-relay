/** Outils communs du relais : masquage des identifiants, écriture atomique, tailles. */
import { promises as fs } from "node:fs"
import path from "node:path"

/** rtsp://user:motdepasse@hote/flux → rtsp://***@hote/flux ; aussi dans un texte libre (journaux FFmpeg). */
export function maskUrl(text) {
  return String(text).replace(/(rtsps?:\/\/)[^\s/@]*@/gi, "$1***@")
}

/** Écrit un fichier entier ou rien (fichier temporaire puis renommage). */
export async function writeAtomic(file, data) {
  const tmp = `${file}.${process.pid}.tmp`
  await fs.writeFile(tmp, data)
  await fs.rename(tmp, file)
}

export const mb = (b) => `${(b / 1_048_576).toFixed(1)} Mo`

/** Taille prévue : débit (bit/s) × durée (s) / 8, avec une marge (métadonnées, fluctuations). */
export const expectedBytes = (bitsPerSecond, seconds, margin = 0.15) => Math.ceil(((bitsPerSecond * seconds) / 8) * (1 + margin))

export function log(level, message, extra) {
  const line = `${new Date().toISOString()} ${level.toUpperCase()} ${maskUrl(message)}${extra ? ` ${maskUrl(JSON.stringify(extra))}` : ""}`
  if (level === "error" || level === "warn") console.error(line)
  else console.log(line)
}

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

export async function dirSize(dir) {
  let total = 0
  for (const name of await fs.readdir(dir).catch(() => [])) {
    const st = await fs.stat(path.join(dir, name)).catch(() => null)
    if (st?.isFile()) total += st.size
  }
  return total
}

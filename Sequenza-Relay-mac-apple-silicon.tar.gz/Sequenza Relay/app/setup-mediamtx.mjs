#!/usr/bin/env node
/**
 * Installe MediaMTX (passerelle RTSP → WebRTC) pour Sequenza Relay :
 *
 *   npm run relay:setup
 *
 * La version téléchargeable du relais l'appelle elle-même au premier lancement.
 * Version figée, téléchargée depuis le dépôt officiel (github.com/bluenviron/mediamtx), empreinte
 * SHA-256 vérifiée avant extraction.
 */
import { spawnSync } from "node:child_process"
import { createHash } from "node:crypto"
import { promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { defaultMediamtxDir } from "./mediamtx.mjs"

export const MEDIAMTX_VERSION = "v1.21.2"

function asset() {
  const arch = { x64: "amd64", arm64: "arm64" }[process.arch]
  if (!arch) throw new Error(`Architecture non prise en charge : ${process.arch}`)
  if (process.platform === "win32") return `mediamtx_${MEDIAMTX_VERSION}_windows_${arch}.zip`
  if (process.platform === "darwin") return `mediamtx_${MEDIAMTX_VERSION}_darwin_${arch}.tar.gz`
  return `mediamtx_${MEDIAMTX_VERSION}_linux_${arch}.tar.gz`
}

async function download(url) {
  const r = await fetch(url, { redirect: "follow" })
  if (!r.ok) throw new Error(`Téléchargement impossible (${r.status}) : ${url}`)
  return Buffer.from(await r.arrayBuffer())
}

/** Télécharge, vérifie et extrait MediaMTX dans `dest`. Renvoie le chemin de l'exécutable. */
export async function installMediamtx(dest = defaultMediamtxDir(), say = (m) => console.log(m)) {
  const name = asset()
  const base = `https://github.com/bluenviron/mediamtx/releases/download/${MEDIAMTX_VERSION}`
  say(`Installation de MediaMTX ${MEDIAMTX_VERSION} (une seule fois)…`)
  const sums = (await download(`${base}/checksums.sha256`)).toString("utf8")
  const expected = sums
    .split("\n")
    .map((l) => l.trim().split(/\s+/))
    .find(([, f]) => f?.replace(/^\*/, "") === name)?.[0]
  if (!expected) throw new Error(`Empreinte introuvable pour ${name}`)
  const archive = await download(`${base}/${name}`)
  const actual = createHash("sha256").update(archive).digest("hex")
  if (actual !== expected) throw new Error(`Empreinte SHA-256 différente : attendu ${expected}, obtenu ${actual}. Fichier rejeté.`)
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(), "mediamtx-"))
  try {
    const file = path.join(tmp, name)
    await fs.writeFile(file, archive)
    await fs.mkdir(dest, { recursive: true })
    // tar sait extraire les .zip sous Windows 10+ (bsdtar) comme les .tar.gz ailleurs.
    const tar = process.platform === "win32" ? path.join(process.env.SystemRoot ?? "C:\\Windows", "System32", "tar.exe") : "tar"
    const r = spawnSync(tar, ["-xf", file, "-C", dest], { stdio: "inherit" })
    if (r.status !== 0) throw new Error("Extraction impossible.")
    await fs.writeFile(path.join(dest, "VERSION"), `${MEDIAMTX_VERSION}\n${actual}\n`)
  } finally {
    await fs.rm(tmp, { recursive: true, force: true })
  }
  say(`MediaMTX installé (empreinte vérifiée : ${actual.slice(0, 16)}…).`)
  return path.join(dest, process.platform === "win32" ? "mediamtx.exe" : "mediamtx")
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await installMediamtx(process.argv[2] ?? defaultMediamtxDir())
  console.log("Relancez `npm run relay` : le direct passera par WebRTC.")
}

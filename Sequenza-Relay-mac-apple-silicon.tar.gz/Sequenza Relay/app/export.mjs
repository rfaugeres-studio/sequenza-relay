/**
 * Export d'un extrait du buffer en MP4.
 *
 * Mode « qualité d'origine » (par défaut) : remultiplexage sans réencodage. L'extrait commence au
 * début du segment qui contient IN : chaque segment commence par une image clé, donc le début est
 * toujours décodable et toujours AVANT IN (jusqu'à un segment plus tôt). C'est la seule découpe
 * possible sans réencoder ; l'interface l'annonce.
 * Mode « précis » : réencodage H.264 (qualité élevée), découpe à l'image près.
 * Si l'extrait traverse une rupture avec changement de codec ou de résolution, seul le mode
 * précis est possible.
 *
 * Pendant l'export, les segments nécessaires sont verrouillés (jamais supprimés), l'acquisition
 * continue, et un export annulé ou en échec ne laisse aucun fichier partiel.
 */
import { spawn } from "node:child_process"
import { promises as fs } from "node:fs"
import path from "node:path"
import readline from "node:readline"
import { log } from "./util.mjs"

export class ExportJob {
  constructor({ id, ring, ffmpeg = "ffmpeg", inMs, outMs, precise = false, stream = null, outDir }) {
    Object.assign(this, { id, ring, ffmpeg, inMs, outMs, precise, stream, outDir })
    this.state = "pending"
    this.progress = 0
    this.error = null
    this.file = path.join(outDir, `extrait-${id}.mp4`)
    this.proc = null
    this.startedAt = Date.now()
  }

  toJSON() {
    return { id: this.id, state: this.state, progress: this.progress, error: this.error, inMs: this.inMs, outMs: this.outMs, precise: this.precise, actualInMs: this.actualInMs ?? null, bytes: this.bytes ?? null }
  }

  async run() {
    const owner = `export:${this.id}`
    const segs = this.ring.range(this.inMs, this.outMs)
    if (!segs.length) return this.fail("Cette partie n'est plus dans le buffer.")
    if (this.outMs - this.inMs < 500) return this.fail("L'extrait doit durer au moins 0,5 s.")
    const codecs = new Set(segs.map((s) => s.codec))
    if (!this.precise && codecs.size > 1) this.precise = true
    this.ring.lock(owner, segs[0].startMs, segs.at(-1).endMs, Infinity)
    await fs.mkdir(this.outDir, { recursive: true })
    const list = path.join(this.outDir, `extrait-${this.id}.txt`)
    await fs.writeFile(list, segs.map((s) => `file '${path.join(this.ring.dir, s.file).replace(/\\/g, "/").replace(/'/g, "'\\''")}'`).join("\n"))
    // Précis : position exacte dans le premier segment. Sans réencodage : début du segment (image clé).
    const ss = this.precise ? Math.max(0, (this.inMs - segs[0].startMs) / 1000) : 0
    const t = (this.outMs - (this.precise ? this.inMs : segs[0].startMs)) / 1000
    const video = this.precise ? ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"] : ["-c:v", "copy", ...(segs[0].codec === "hevc" ? ["-tag:v", "hvc1"] : [])]
    const args = [
      "-hide_banner",
      "-nostdin",
      "-loglevel",
      "error",
      "-y",
      "-f",
      "concat",
      "-safe",
      "0",
      "-i",
      list,
      ...(this.precise ? ["-ss", ss.toFixed(3)] : []),
      "-t",
      t.toFixed(3),
      "-map",
      "0:v:0",
      "-map",
      "0:a:0?",
      ...video,
      "-c:a",
      "aac",
      "-movflags",
      "+faststart",
      "-progress",
      "pipe:1",
      this.file,
    ]
    this.state = "running"
    try {
      await new Promise((resolve, reject) => {
        const p = spawn(this.ffmpeg, args, { stdio: ["ignore", "pipe", "pipe"], windowsHide: true })
        this.proc = p
        let stderr = ""
        p.stderr.on("data", (d) => (stderr = (stderr + d).slice(-2000)))
        readline.createInterface({ input: p.stdout }).on("line", (line) => {
          const m = /^out_time_us=(\d+)/.exec(line)
          if (m) this.progress = Math.min(0.99, Number(m[1]) / 1e6 / t)
        })
        p.on("error", reject)
        p.on("exit", (code) => (code === 0 ? resolve() : reject(new Error(this.state === "cancelled" ? "annulé" : stderr.trim().split("\n").pop() || `FFmpeg ${code}`))))
      })
      const st = await fs.stat(this.file)
      this.bytes = st.size
      // Début réel : sans réencodage, le début du segment (image clé) qui contient IN.
      this.actualInMs = this.precise ? this.inMs : segs[0].startMs
      this.state = "done"
      this.progress = 1
      log("info", `Export ${this.id} terminé (${st.size} octets)`)
    } catch (e) {
      await fs.rm(this.file, { force: true })
      if (this.state !== "cancelled") this.fail(e.message)
    } finally {
      this.proc = null
      this.ring.unlock(owner)
      await fs.rm(list, { force: true })
    }
  }

  fail(message) {
    this.state = "error"
    this.error = message
  }

  async cancel() {
    if (this.state !== "running" && this.state !== "pending") return
    this.state = "cancelled"
    this.proc?.kill("SIGKILL")
  }
}

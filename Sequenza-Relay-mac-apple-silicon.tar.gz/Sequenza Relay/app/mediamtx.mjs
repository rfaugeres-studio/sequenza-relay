/**
 * Passerelle vidéo MediaMTX, pilotée par Sequenza Relay.
 *
 *   caméra ──RTSP──▶ MediaMTX (une seule connexion à la caméra)
 *                      ├─ chemin « cam »    : flux d'origine
 *                      ├─ chemin « cam264 » : H.264 converti par FFmpeg si la caméra n'envoie pas du H.264
 *                      ├─ WebRTC (WHEP)     : direct à faible latence, relayé par Sequenza Relay
 *                      └─ RTSP local        : lu par l'acquisition du replay (buffer 60 min)
 *
 * Sécurité : tout écoute sur 127.0.0.1 ; un utilisateur interne au mot de passe aléatoire (renouvelé
 * à chaque lancement) est le seul autorisé ; l'adresse de la caméra n'existe que dans la configuration
 * générée, sur cet ordinateur. Le navigateur ne parle jamais à MediaMTX directement.
 */
import { spawn, spawnSync } from "node:child_process"
import { randomBytes } from "node:crypto"
import { existsSync, promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import readline from "node:readline"
import { log, maskUrl, writeAtomic } from "./util.mjs"

export function defaultMediamtxDir() {
  const base = process.env.LOCALAPPDATA ?? (process.platform === "darwin" ? path.join(os.homedir(), "Library", "Application Support") : path.join(os.homedir(), ".local", "share"))
  return path.join(base, "Sequenza", "mediamtx")
}

/** MediaMTX : chemin explicite, sinon installation de `npm run relay:setup`, sinon PATH. */
export function findMediamtx(explicit) {
  const exe = process.platform === "win32" ? "mediamtx.exe" : "mediamtx"
  for (const c of [explicit, process.env.MEDIAMTX_PATH, path.join(defaultMediamtxDir(), exe)]) if (c && existsSync(c)) return c
  const r = spawnSync(process.platform === "win32" ? "where" : "which", ["mediamtx"], { encoding: "utf8" })
  return r.status === 0 ? r.stdout.split(/\r?\n/)[0].trim() || null : null
}

/** FFmpeg présent ? (seulement nécessaire pour convertir une caméra H.265 en H.264) */
export function ffmpegAvailable(ffmpeg = "ffmpeg") {
  try {
    return spawnSync(ffmpeg, ["-hide_banner", "-version"], { timeout: 10_000, windowsHide: true }).status === 0
  } catch {
    return false
  }
}

/** Codecs vidéo qu'un navigateur lit partout (WebRTC et MSE). Le reste est converti en H.264. */
export const needsTranscode = (codec) => !!codec && !/^(H264|AVC)$/i.test(codec)

const ENCODERS = ["h264_nvenc", "h264_qsv", "h264_amf", "libx264"]
let encoderCache = null

/** Premier encodeur H.264 qui fonctionne vraiment sur cet ordinateur (matériel d'abord). */
export function pickEncoder(ffmpeg = "ffmpeg", forced = process.env.SEQUENZA_H264_ENCODER) {
  if (forced) return forced
  if (encoderCache) return encoderCache
  for (const enc of ENCODERS) {
    const r = spawnSync(ffmpeg, ["-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=25", "-frames:v", "10", "-c:v", enc, "-f", "null", "-"], { timeout: 15_000, windowsHide: true })
    if (r.status === 0) return (encoderCache = enc)
  }
  return (encoderCache = "libx264")
}

export function encoderArgs(enc, fps) {
  const gop = String(Math.max(10, Math.round((fps || 25) * 2)))
  const common = ["-g", gop, "-bf", "0", "-pix_fmt", "yuv420p"]
  if (enc === "libx264") return ["-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency", "-profile:v", "high", "-crf", "21", ...common]
  if (enc === "h264_nvenc") return ["-c:v", enc, "-preset", "p4", "-tune", "ll", "-rc", "vbr", "-cq", "23", ...common]
  if (enc === "h264_qsv") return ["-c:v", enc, "-preset", "veryfast", "-global_quality", "23", ...common]
  return ["-c:v", enc, "-quality", "speed", "-rc", "cqp", "-qp_i", "22", "-qp_p", "24", ...common]
}

/** Ports libres sur 127.0.0.1 (choisis au lancement, jamais exposés sur le réseau). */
async function freePorts(n) {
  const net = await import("node:net")
  const out = []
  const servers = []
  for (let i = 0; i < n; i++) {
    const s = net.createServer()
    await new Promise((r) => s.listen(0, "127.0.0.1", r))
    out.push(s.address().port)
    servers.push(s)
  }
  await Promise.all(servers.map((s) => new Promise((r) => s.close(r))))
  return out
}

const yamlStr = (s) => JSON.stringify(String(s))

export function buildConfig({ source, user, pass, ports, transcodePath = "cam264" }) {
  const host = "127.0.0.1"
  return [
    "logLevel: info",
    "logDestinations: [stdout]",
    "readTimeout: 10s",
    "writeTimeout: 10s",
    "authMethod: internal",
    "authInternalUsers:",
    `  - user: ${yamlStr(user)}`,
    `    pass: ${yamlStr(pass)}`,
    `    ips: ["127.0.0.1", "::1"]`,
    "    permissions:",
    "      - action: publish",
    "      - action: read",
    "      - action: api",
    "api: yes",
    `apiAddress: ${host}:${ports.api}`,
    "metrics: no",
    "pprof: no",
    "playback: no",
    "rtsp: yes",
    "rtspTransports: [tcp]",
    `rtspAddress: ${host}:${ports.rtsp}`,
    "rtmp: no",
    // HLS : direct de secours quand WebRTC n'est pas possible (relayé par Sequenza Relay).
    "hls: yes",
    `hlsAddress: ${host}:${ports.hls}`,
    "hlsVariant: mpegts",
    "hlsSegmentCount: 6",
    "hlsSegmentDuration: 1s",
    "hlsAlwaysRemux: yes",
    "srt: no",
    "moq: no",
    "webrtc: yes",
    `webrtcAddress: ${host}:${ports.webrtc}`,
    `webrtcLocalUDPAddress: ${host}:${ports.udp}`,
    `webrtcLocalTCPAddress: ${host}:${ports.tcp}`,
    "webrtcIPsFromInterfaces: no",
    `webrtcAdditionalHosts: ["127.0.0.1"]`,
    "webrtcICEServers2: []",
    "pathDefaults:",
    "  record: no",
    "paths:",
    "  cam:",
    `    source: ${yamlStr(source.url)}`,
    `    rtspTransport: ${source.transport === "udp" ? "udp" : "tcp"}`,
    "    sourceOnDemand: no",
    `  ${transcodePath}:`,
    "    source: publisher",
    "",
  ].join("\n")
}

export class Gateway {
  constructor({ bin, workDir, ffmpeg = "ffmpeg", onState = () => {} }) {
    Object.assign(this, { bin, workDir, ffmpeg, onState })
    this.user = "sequenza"
    this.pass = null
    this.ports = null
    this.proc = null
    this.transcoder = null
    this.stopped = true
    this.info = { ready: false, codec: null, audio: null, transcoded: false, encoder: null, livePath: null, lastError: null, restarts: 0, video: null, transcodeUnavailable: false }
    this.hasFfmpeg = null
  }

  get available() {
    return !!this.bin
  }

  readUrl(p = this.info.livePath ?? "cam") {
    return `rtsp://${this.user}:${this.pass}@127.0.0.1:${this.ports.rtsp}/${p}`
  }

  whepUrl(p = this.info.livePath ?? "cam") {
    return `http://127.0.0.1:${this.ports.webrtc}/${p}/whep`
  }

  /** Adresse HLS (MediaMTX) d'un fichier du direct. */
  hlsUrl(rest) {
    return `http://127.0.0.1:${this.ports.hls}/${rest}`
  }

  authHeader() {
    return `Basic ${Buffer.from(`${this.user}:${this.pass}`).toString("base64")}`
  }

  /** Démarre MediaMTX, attend la caméra, choisit le chemin lisible par le navigateur. Résout avec ce chemin. */
  async start(source, { transcode = "auto" } = {}) {
    this.stopped = false
    this.source = source
    this.transcodeMode = transcode
    this.pass = randomBytes(18).toString("base64url")
    const [api, rtsp, webrtc, udp, tcp, hls] = await freePorts(6)
    this.ports = { api, rtsp, webrtc, udp, tcp, hls }
    this.hasFfmpeg ??= ffmpegAvailable(this.ffmpeg)
    await fs.mkdir(this.workDir, { recursive: true })
    this.configFile = path.join(this.workDir, "mediamtx.yml")
    await writeAtomic(this.configFile, buildConfig({ source, user: this.user, pass: this.pass, ports: this.ports }))
    this.info = { ready: false, codec: null, audio: null, transcoded: false, encoder: null, livePath: null, lastError: null, restarts: this.info.restarts, video: null, transcodeUnavailable: false }
    this.spawn()
    this.poll = setInterval(() => void this.refresh(), 1000)
  }

  spawn() {
    if (this.stopped) return
    const p = spawn(this.bin, [this.configFile], { cwd: this.workDir, stdio: ["ignore", "pipe", "pipe"], windowsHide: true })
    this.proc = p
    const onLine = (line) => {
      const clean = maskUrl(line.replace(this.pass, "***"))
      if (/\bERR\b|error/i.test(clean) && /cam/.test(clean)) {
        this.info.lastError = clean.replace(/^.*?(ERR|WAR)\s*/, "").slice(0, 300)
        log("warn", `MediaMTX : ${this.info.lastError}`)
      }
    }
    readline.createInterface({ input: p.stdout }).on("line", onLine)
    readline.createInterface({ input: p.stderr }).on("line", onLine)
    p.on("error", (e) => {
      this.info.lastError = `MediaMTX ne démarre pas : ${e.message}`
    })
    p.on("exit", (code) => {
      if (this.proc === p) this.proc = null
      if (this.stopped) return
      this.info.restarts++
      this.info.ready = false
      log("warn", `MediaMTX arrêté (code ${code}), relance dans 2 s`)
      this.respawnTimer = setTimeout(() => this.spawn(), 2000)
    })
  }

  async api(p) {
    const r = await fetch(`http://127.0.0.1:${this.ports.api}${p}`, { headers: { authorization: this.authHeader() } })
    if (!r.ok) throw new Error(`API MediaMTX ${r.status}`)
    return r.json()
  }

  /** État du chemin « cam » : prêt ? quel codec ? Lance ou arrête la conversion H.264 en conséquence. */
  async refresh() {
    if (this.stopped || !this.proc) return
    let cam
    try {
      cam = await this.api("/v3/paths/get/cam")
    } catch {
      this.info.ready = false
      return
    }
    const tracks = (cam.tracks2 ?? cam.tracks ?? []).map((t) => (typeof t === "string" ? { codec: t } : t))
    const VIDEO = /^(H26[45]|AVC|HEVC|AV1|VP[89]|MJPEG|M-JPEG|MPEG-4 Video|MPEG-1\/2 Video)$/i
    const videoTrack = tracks.find((t) => VIDEO.test(t.codec)) ?? null
    const video = videoTrack?.codec ?? null
    this.info.audio = tracks.find((t) => t !== videoTrack)?.codec ?? null
    if (!cam.ready || !video) {
      this.info.ready = false
      return
    }
    this.info.codec = video
    const wanted = this.transcodeMode === "always" || (this.transcodeMode !== "off" && needsTranscode(video))
    // Sans FFmpeg, pas de conversion : le flux d'origine est proposé tel quel (lisible si le navigateur sait le décoder).
    const convert = wanted && !!this.hasFfmpeg
    this.info.transcodeUnavailable = wanted && !this.hasFfmpeg
    if (this.info.transcodeUnavailable) this.info.lastError = `Caméra ${video} : installez FFmpeg sur cet ordinateur pour la convertir en H.264 (lisible par tous les navigateurs).`
    if (convert && !this.transcoder) this.startTranscoder()
    this.info.transcoded = convert
    const props = (t) => ({ codec: String(t.codec).toLowerCase().replace("hevc", "h265"), width: t.codecProps?.width ?? 0, height: t.codecProps?.height ?? 0, fps: null })
    if (!convert) {
      this.info.livePath = "cam"
      this.info.video = props(videoTrack)
      this.info.ready = true
      return
    }
    try {
      const out = await this.api("/v3/paths/get/cam264")
      this.info.ready = !!out.ready
      if (out.ready) {
        this.info.livePath = "cam264"
        const t = (out.tracks2 ?? []).find((x) => VIDEO.test(x.codec))
        this.info.video = t ? props(t) : { ...props(videoTrack), codec: "h264" }
      }
    } catch {
      this.info.ready = false
    }
  }

  /** FFmpeg : caméra (H.265…) → H.264 navigateur, publié dans MediaMTX. Relancé s'il s'arrête. */
  startTranscoder() {
    if (this.stopped) return
    const enc = pickEncoder(this.ffmpeg)
    this.info.encoder = enc
    const fps = this.source?.fps ?? 25
    const args = [
      "-hide_banner",
      "-nostdin",
      "-loglevel",
      "error",
      "-rtsp_transport",
      "tcp",
      "-i",
      this.readUrl("cam"),
      "-map",
      "0:v:0",
      "-map",
      "0:a:0?",
      ...encoderArgs(enc, fps),
      "-c:a",
      "libopus",
      "-b:a",
      "64k",
      "-f",
      "rtsp",
      "-rtsp_transport",
      "tcp",
      this.readUrl("cam264"),
    ]
    log("info", `Conversion ${this.info.codec} → H.264 (${enc}) pour le navigateur`)
    const p = spawn(this.ffmpeg, args, { stdio: ["ignore", "ignore", "pipe"], windowsHide: true })
    this.transcoder = p
    readline.createInterface({ input: p.stderr }).on("line", (l) => {
      this.info.lastError = `Conversion H.264 : ${maskUrl(l.replace(this.pass, "***")).slice(0, 300)}`
    })
    p.on("exit", () => {
      if (this.transcoder === p) this.transcoder = null
      if (this.stopped) return
      this.info.ready = false
      // Relancée au prochain `refresh` quand la caméra est de nouveau prête.
    })
  }

  async stop() {
    this.stopped = true
    clearInterval(this.poll)
    clearTimeout(this.respawnTimer)
    for (const p of [this.transcoder, this.proc]) {
      if (!p) continue
      await new Promise((resolve) => {
        const t = setTimeout(() => {
          try {
            p.kill("SIGKILL")
          } catch {
            /* déjà arrêté */
          }
          resolve()
        }, 3000)
        p.once("exit", () => {
          clearTimeout(t)
          resolve()
        })
        try {
          p.kill("SIGTERM")
        } catch {
          clearTimeout(t)
          resolve()
        }
      })
    }
    this.transcoder = null
    this.proc = null
    this.info.ready = false
  }

  status() {
    const { ready, codec, audio, transcoded, encoder, livePath, lastError, restarts, transcodeUnavailable } = this.info
    return { enabled: true, running: !!this.proc, ready, codec, audio, transcoded, encoder, livePath, webrtc: ready, lastError, restarts, transcodeUnavailable, ffmpeg: !!this.hasFfmpeg }
  }
}

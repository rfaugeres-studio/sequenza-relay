#!/bin/bash
# Sequenza Relay : laissez cette fenêtre ouverte pendant le match.
cd "$(dirname "$0")" || exit 1
./runtime/node ./app/index.mjs --auto-setup "$@"
echo ""
echo "Sequenza Relay est arrêté. Vous pouvez fermer cette fenêtre."

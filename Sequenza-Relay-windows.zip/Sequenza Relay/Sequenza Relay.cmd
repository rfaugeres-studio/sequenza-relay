@echo off
title Sequenza Relay
cd /d "%~dp0"
"%~dp0runtime\node.exe" "%~dp0app\index.mjs" --auto-setup %*
echo.
echo Sequenza Relay est arrete. Appuyez sur une touche pour fermer cette fenetre.
pause >nul
